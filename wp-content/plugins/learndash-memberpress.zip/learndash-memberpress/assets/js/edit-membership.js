jQuery( document ).ready( function( $ ) {
    $( '.product_options_page.learndash .select2' ).select2({
        width: '100%',
        selectionCssClass: 'selection',
        closeOnSelect: false,
    }); 
});